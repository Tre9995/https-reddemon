# RedDemon

RedDemon is a standalone streaming-provider plugin project. It is separate from Nuvio by Me and is designed around a player-neutral API, with player-specific adapters.

## Current foundation

- Node.js / Express service
- Health endpoint: `GET /health`
- Player-neutral API:
  - `GET /api/v1/manifest`
  - `GET /api/v1/catalog?type=movie`
  - `GET /api/v1/streams/:type/:id`
  - `GET /api/v1/subtitles/:type/:id`
- Initial Stremio adapter:
  - `GET /stremio/manifest.json`
  - `GET /stremio/catalog/:type/:catalogId.json`
  - `GET /stremio/stream/:type/:id.json`

The endpoints intentionally return empty results until real, authorized provider modules are configured. This is a working integration skeleton, not a finished source catalogue.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
cp .env.example .env
npm run dev
```

Open `http://localhost:3000/health`.

## Deploy to Render

Create a new **Web Service** from this repository.

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`

Render supplies the `PORT` environment variable automatically.

## Compatibility approach

A single universal plugin format does not exist across all media players. RedDemon therefore uses one shared API and separate adapters for each supported player. The Stremio adapter is the first starter adapter; additional adapters should be implemented against the target player's documented plugin/add-on interface.

## Security and provider policy

Do not commit provider credentials or debrid tokens. Store secrets in the hosting provider's environment settings. Only connect services and media sources the user is authorized to access. Use HTTPS in production.
